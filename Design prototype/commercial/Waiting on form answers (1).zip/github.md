repo: Haseebmzahid/Baagh
branch: main

## Last sync
date: 2026-08-18T10:35:00Z

### Updated in this project
- Read production tokens, brand config and DOM chrome to ground the commercial design language.
- Created the Stage 01 information architecture and user-flow map for the commercial website.
- Locked the existing journey and Fruit Intelligence routes as frozen; commercial routes are additive.

## Screen map
| Project screen | Built from |
| --- | --- |
| BAAGH Commercial IA and Flows.dc.html | src/config/tokens.ts, src/config/brand.ts, src/index.css, src/App.tsx, src/components/dom/SiteHeader.tsx, src/components/dom/CtaPair.tsx, src/components/dom/ScrollCue.tsx, src/components/dom/GradeOverlay.tsx |
